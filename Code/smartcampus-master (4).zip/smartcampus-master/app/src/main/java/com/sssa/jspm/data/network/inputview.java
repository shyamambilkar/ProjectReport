package com.sssa.jspm.data.network;

import android.support.design.widget.TextInputEditText;

/**
 * Created by Shiv on 2/22/2017.
 */

public interface inputview {

    TextInputEditText gettext();

}
