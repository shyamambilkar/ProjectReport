package com.sssa.jspm.misc.utils;

import android.support.v7.graphics.Palette;

/**
 * Created by Shiv on 3/6/2017.
 */

public interface pallete {

    void palettework(Palette palette);
}
