package com.sssa.jspm.data.network;

import com.sssa.jspm.misc.utils.Extras;

/**
 * Created by Shiv on 2/22/2017.
 */

public interface extras {

    Extras getExtras();

}
